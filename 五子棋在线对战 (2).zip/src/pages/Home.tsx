/**
 * 首页组件 - 五子棋游戏页面
 */

import { GomokuGame } from '../components/Gomoku/GomokuGame';

export default function Home() {
  return <GomokuGame />;
}
